//
//  ViewController.swift
//  Assignment2
//
//  Created by Ashwini Shekhar Phadke on 2/19/18.
//  Copyright © 2018 Ashwini Shekhar Phadke. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    
    var round = 0
    var balance = 0
    var totalmoney = 50
    
    @IBOutlet weak var PlayerLabel: UILabel!
    
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var roundLable: UILabel!
    @IBOutlet weak var betLabel: UILabel!
    @IBAction func betSlider(_ sender: UISlider)
    {
        
        betLabel.text = String(Int(sender.value))
        balance = (Int(sender.value))
        
       
    }
    
    @IBAction func helpButton(_ sender: UIButton)
    {
        
        performSegue(withIdentifier: "segue", sender: self)
    }
    @IBOutlet weak var ComputerLabel: UILabel!
    
    
    
    @IBAction func playButton(_ sender: UIButton) {
        playgame()
        round=round + 1
        roundLable.text = "\(round)"
    }
    
    
    @IBOutlet weak var diceoneimg: UIImageView!
    
    
    @IBOutlet weak var dicetwoimage: UIImageView!
    //reset the game
    @IBAction func resetButton(_ sender: UIButton)
    {
         round = 0
        roundLable.text = "\(round)"
         balance = 0
        totalmoney = 50
         totalLabel.text = "\(totalmoney)"
        diceoneimg.image=UIImage(named: "dice1")
        dicetwoimage.image=UIImage(named: "dice1")
         PlayerLabel.text = "0"
        ComputerLabel.text = "0"
         betLabel.text = "0"
    }
    func playgame()
    {
        
        var diceone = arc4random_uniform(6) + 1
        var dicetwo = arc4random_uniform(6) + 1
        PlayerLabel.text = "\(diceone)"
        ComputerLabel.text = "\(dicetwo)"
        diceoneimg.image=UIImage(named: "dice\(diceone)")
        dicetwoimage.image=UIImage(named: "dice\(dicetwo)")
        
        if(diceone == dicetwo)
        {
            totalmoney = Int((totalmoney + balance)*2)
            totalLabel.text = "\(totalmoney)"
            let alertController = UIAlertController(title : "It's a tie!!",message: "Your money doubles!!!!",preferredStyle: .alert)
            let defaultaction = UIAlertAction(title: "Cancel",style : .default,handler: nil)
            alertController.addAction(defaultaction)
            present(alertController,animated: true, completion: nil)
            
            
        }

        if(diceone > dicetwo)
        {
            totalmoney = Int(totalmoney + balance)
            totalLabel.text = "\(totalmoney)"
            let alertController = UIAlertController(title : "Congrats!!",message: "You won!",preferredStyle: .alert)
            let defaultaction = UIAlertAction(title: "Cancel",style : .default,handler: nil)
            alertController.addAction(defaultaction)
            present(alertController,animated: true, completion: nil)
            
            
        }
        if(diceone < dicetwo)
        {
            totalmoney = Int(totalmoney - balance)
            totalLabel.text = "\(totalmoney)"
            let alertController = UIAlertController(title : "Sorry!!",message: "You lost!Game wins!",preferredStyle: .alert)
            let defaultaction = UIAlertAction(title: "Cancel",style : .default,handler: nil)
            alertController.addAction(defaultaction)
            present(alertController,animated: true, completion: nil)
            
        }
       
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        diceoneimg.image=UIImage(named: "dice1")
        dicetwoimage.image=UIImage(named: "dice1")
        totalLabel.text = "\(totalmoney)"
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

